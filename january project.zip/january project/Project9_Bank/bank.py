balance = 1000   # fixed balance

try:
    withdraw = float(input("Enter amount to withdraw: "))

    if withdraw > balance:
        print("Insufficient Balance")
    else:
        balance -= withdraw
        print("Withdrawal Successful")
        print("Remaining Balance =", balance)

except ValueError:
    print("Please enter numbers only!")
