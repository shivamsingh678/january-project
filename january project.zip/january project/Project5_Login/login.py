username = "mamaji"
password = "1234"

try:
    u = input("Enter username: ")
    p = input("Enter password: ")

    if u == username and p == password:
        print("Login Successful!")
    else:
        print("Invalid Username or Password")

except Exception as e:
    print("Something went wrong:", e)
