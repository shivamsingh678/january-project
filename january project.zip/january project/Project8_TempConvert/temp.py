try:
    c = float(input("Enter temperature in Celsius: "))

    f = (c * 9/5) + 32

    print("Temperature in Fahrenheit =", f)

except ValueError:
    print("Please enter numbers only!")
