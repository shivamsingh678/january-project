try:
    text = input("Write something to save in file: ")

    f = open("notes.txt", "w")
    f.write(text)
    f.close()

    print("Text saved successfully in notes.txt")

except Exception as e:
    print("Something went wrong:", e)
