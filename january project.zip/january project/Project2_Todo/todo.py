tasks = []

while True:
    print("\n1. Add Task")
    print("2. View Tasks")
    print("3. Exit")

    choice = input("Enter your choice: ")

    try:
        if choice == "1":
            task = input("Enter task: ")
            tasks.append(task)
            print("Task added successfully!")

        elif choice == "2":
            print("\nYour Tasks:")
            for t in tasks:
                print("- ", t)

        elif choice == "3":
            print("Exiting program...")
            break

        else:
            print("Invalid choice! Please select 1, 2 or 3.")

    except Exception as e:
        print("An error occurred:", e)
