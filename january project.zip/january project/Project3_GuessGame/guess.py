import random

secret = random.randint(1, 10)

try:
    guess = int(input("Guess a number between 1 and 10: "))

    if guess == secret:
        print(" Correct Guess! You win!")
    else:
        print(" Wrong Guess! The correct number was:", secret)

except ValueError:
    print("Please enter numbers only!")
