score = 0

try:
    q1 = input("1. What is the capital of India? ")

    if q1.lower() == "delhi":
        score += 1

    q2 = input("2. What is 2 + 2? ")

    if q2 == "4":
        score += 1

    print("Your total score is:", score)

except Exception as e:
    print("Something went wrong:", e)
