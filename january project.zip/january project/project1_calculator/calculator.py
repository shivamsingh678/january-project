try:
    a = float(input("Enter first number: "))
    b = float(input("Enter second number: "))
    op = input("Enter operator (+ - * /): ")

    if op == '+':
        print("Result =", a + b)
    elif op == '-':
        print("Result =", a - b)
    elif op == '*':
        print("Result =", a * b)
    elif op == '/':
        print("Result =", a / b)
    else:
        print("Invalid operator")

except ZeroDivisionError:
    print("You cannot divide a number by 0!")

except ValueError:
    print("Please enter valid numeric input only!")
