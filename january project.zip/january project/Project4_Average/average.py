try:
    m1 = float(input("Enter marks 1: "))
    m2 = float(input("Enter marks 2: "))
    m3 = float(input("Enter marks 3: "))

    avg = (m1 + m2 + m3) / 3

    print("Average Marks =", avg)

except ValueError:
    print("Please enter numbers only!")
